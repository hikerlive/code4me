/*
This code was written by Mohammed Lokhandwala. (lokhandwalamohammed@yahoo.com)

You may use this code in your projects provided the project is for non commercial use. 
You (or your company) should not be profiting from it. 

For commercial use, a written permission from the author is required.

This code is given without any warranties. You should use it at your own risk. Author is NOT
liable for any damage caused due to use of this code even if incidental.

*/
#pragma warning(disable:4786)

#include<iostream>
#include<string>

#include "ErrorConstants.h"
#include "EpochTypes.h"
#include "CommandLineParser.h"

using namespace std;
using namespace Epoch::Types;
using namespace Epoch::ErrorConstants;
using namespace Epoch::Foundation;

int main(int argc, char * argv[])
{
	try
	{
		CommandLineParser parser;
		parser.parse(argc, argv);

		vectorOfString vec_RequiredPairs;
		vec_RequiredPairs.push_back("src");
		vec_RequiredPairs.push_back("dst");
		vec_RequiredPairs.push_back("versionize");
		
		if(!parser.verifyCompulsory(vec_RequiredPairs))
		{
			cerr << endl << "Invalid Parameters." << endl;
			cerr << "Syntax requires:  /src=\"source directory\" /dst=\"destination directory\" /versionize=true/false" << endl;

			throw InvalidInput;
		}

		cout << parser.getValue("src","Blank").c_str() << endl;
		cout << parser.getValue("dst","Blank").c_str() << endl;
		cout << parser.getValue("versionize","true").c_str() << endl;
	}
	catch(ProcessErrors code)
	{
		cerr << endl << "Process Failed due to Exception:" << code << endl;
		return code;
	}
	catch(...)
	{
		cerr << endl << "Unhandled Exception encountered";
		return UnhandledException;
	}
	
	return Success  ;
}

